package VO;

public class BasketVo {

}
