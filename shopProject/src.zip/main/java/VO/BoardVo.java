package VO;

public class BoardVo {

}
