package VO;

import java.util.List;

public class OrderVo {
	private String name;
	private String product_id;
	private String total_price;
	private String size_type;
	private String quantity;
	private List<OrderVo> orderVo;
	
	
	@Override
	public String toString() {
		return "OrderVo [name=" + name + ", product_id=" + product_id + ", total_price=" + total_price + ", size_type="
				+ size_type + ", quantity=" + quantity + "]";
	}
	
	
	
	public List<OrderVo> getOrderVo() {
		return orderVo;
	}



	public void setOrderVo(List<OrderVo> orderVo) {
		this.orderVo = orderVo;
	}



	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public String getTotal_price() {
		return total_price;
	}
	public void setTotal_price(String total_price) {
		this.total_price = total_price;
	}
	public String getSize_type() {
		return size_type;
	}
	public void setSize_type(String size_type) {
		this.size_type = size_type;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	
}
