package VO;

import java.sql.Date;

public class MemberVo {

	private String customer_id;
	private String id;
	private String password;
	private String name;
	private int age;
	private String sex;
	private String address;
	private String address_detail;
	private String identity_number;
	private String email;
	private String phone_number;
	private String passwordCheck;
	private Date start_date;
	private Date end_date;


	@Override
	public String toString() {
		return "MemberVo [customer_id=" + customer_id + ", id=" + id + ", password=" + password + ", name=" + name
				+ ", age=" + age + ", sex=" + sex + ", address=" + address + ", address_detail=" + address_detail
				+ ", identity_number=" + identity_number + ", email=" + email + ", phone_number=" + phone_number
				+ ", passwordCheck=" + passwordCheck + ", start_date=" + start_date + ", end_date=" + end_date + "]";
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public String getAddress_detail() {
		return address_detail;
	}

	public void setAddress_detail(String address_detail) {
		this.address_detail = address_detail;
	}

	public String getPasswordCheck() {
		return passwordCheck;
	}

	public void setPasswordCheck(String passwordCheck) {
		this.passwordCheck = passwordCheck;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getIdentity_number() {
		return identity_number;
	}

	public void setIdentity_number(String identity_number) {
		this.identity_number = identity_number;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getPassword() {
		return password;
	}

	public int getAge() {
		return age;
	}

	public String getEmail() {
		return email;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

}
