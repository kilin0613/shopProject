package VO;

public class FavoriteVo {

	private String customer_id;
	private String product_id;
	
	@Override
	public String toString() {
		return "FavoriteVo [customer_id=" + customer_id + ", product_id=" + product_id + "]";
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
}
