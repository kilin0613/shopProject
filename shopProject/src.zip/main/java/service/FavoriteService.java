package service;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import DAO.FavoriteDao;
import DAO.ProductDao;
import VO.FavoriteVo;
import VO.ProductVo;

public class FavoriteService {

	@Autowired
	FavoriteDao favoriteDao;

	@Autowired
	ProductDao productDao;

	public void insertFavorites(FavoriteVo favoriteVo) {

		favoriteDao.insertFavorites(favoriteVo);
	}

	public FavoriteVo selectOneFavorites(FavoriteVo favoriteVo) {

		favoriteVo = favoriteDao.selectOneFavorite(favoriteVo);
		return favoriteVo;
	}

	public List<ProductVo> selectAllFavorites(String customer_id) {
		
		List<ProductVo> favoriteProduct_id = favoriteDao.selectFavoritesProduct(customer_id);
		for(int i=0;i<favoriteProduct_id.size();i++) {
			String blobToBase64 = Base64.getEncoder().encodeToString(favoriteProduct_id.get(i).getP_blob());
			favoriteProduct_id.get(i).setBlobToBase64(blobToBase64);
		}
		
		return favoriteProduct_id;
	}

	public void deleteFavorites(FavoriteVo favoriteVo) {
		favoriteDao.deleteFavorite(favoriteVo);

	}

}
