package service;

import org.springframework.beans.factory.annotation.Autowired;

import DAO.OrderDao;


public class OrderService {

	@Autowired
	OrderDao orderDao;
	
	
	public void orderService() {
		
	}
	

	
}
