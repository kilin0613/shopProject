package DAO;

public class BoardDao {

}
