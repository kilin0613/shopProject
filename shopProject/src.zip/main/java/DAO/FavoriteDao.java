package DAO;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import VO.FavoriteVo;
import VO.ProductVo;

public class FavoriteDao {
	
	@Autowired
	SqlSession session;
	
	
	public void insertFavorites(FavoriteVo favoriteVo) {
		session.insert("Favorites.insertFavorites",favoriteVo);
	}
	
	public FavoriteVo selectOneFavorite(FavoriteVo favoriteVo) {
		
		favoriteVo = session.selectOne("Favorites.selectOneFavorite", favoriteVo);
		return favoriteVo;
	}	
	
	public void deleteFavorite(FavoriteVo favoriteVo) {
		session.delete("Favorites.deleteFavorite",favoriteVo);
	}
	
	public List<ProductVo> selectFavoritesProduct(String customer_id) {
			List<ProductVo> favoriteProduct = session.selectList("ProductDao.selectFavoritesProduct",customer_id);
		 return favoriteProduct;
	}
	
}
