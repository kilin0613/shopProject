package DAO;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import VO.ProductVo;

public class ProductDao {

	@Autowired
	SqlSession session;

	public List<ProductVo> selectMainProduct() {
		List<ProductVo> productVo = session.selectList("ProductDao.mainProduct");
		return productVo;
	}
	
	public ProductVo selectProductDetail(String product_id) {
		
		return (ProductVo)session.selectOne("ProductDao.selectProductDetail",product_id);
	}
	
	public List<ProductVo> selectProductSearch(String keyword){
		List<ProductVo> productVo = session.selectList("ProductDao.searchKeyword",keyword);
		return productVo;
	}

}
