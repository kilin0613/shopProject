package DAO;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import VO.MemberVo;

public class MemberDao {

	@Autowired
	SqlSession session;

	public void insertMember(MemberVo memberVo) {

		session.insert("MemberDao.insertMember", memberVo);
	}

	public String selectMemberId(String memberId) {
		String id = session.selectOne("MemberDao.selectId", memberId);
		return id;
	}

	@SuppressWarnings("finally")
	public MemberVo selectMemberInfo(MemberVo memberVo) {

		try {
			memberVo = session.selectOne("MemberDao.selectInfo", memberVo);
		} catch (Exception e) {
			e.printStackTrace();
			memberVo = null;
		} finally {
			return memberVo;
		}
	}

	public void updateInfo(MemberVo memberVo) {
		try {
			session.update("MemberDao.updateInfo", memberVo);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void updateMemberWithdrawal(MemberVo memberVo) {
		session.update("MemberDao.updateEndDate",memberVo);
	}
	
	public MemberVo selectCheckIdEmail(MemberVo memberVo) {
		return (MemberVo)session.selectOne("MemberDao.selectCheckIdEmail",memberVo);
	}
	
	
}
