package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import VO.MemberVo;
import service.MemberService;

@Controller
public class MemberController {

	@Autowired
	MemberService service;

	@PostMapping("/signUp")
	public String postSignUp(Model model, MemberVo memberVo) {
		int result = service.signUpService(memberVo);

		if (result == 1) {
			return "member/sign/signUpOk";
		} else {
			return "sign/signFail";
		}
	}

	@GetMapping("/signUp")
	public String getSignUp(Model model, MemberVo memberVo) {

		return "member/sign/signUp";
	}

	@GetMapping("/infoModify")
	public String getMemberModify(Model model, HttpServletRequest req, MemberVo memberVo) {
		HttpSession session = req.getSession();
		if (session.getAttribute("loginMember") == null) {
			return "redirect:/login";

		}
		
		return "member/myPage/infoModify";
	}

	@PostMapping("/infoModify")
	public String postMemberModify(Model model, HttpServletRequest req, MemberVo memberVo) {
		HttpSession session = req.getSession();

		if (session.getAttribute("loginMember") == null) {
			return "redirect:/login";
		}

		service.updateInfoService(memberVo);
		return "member/myPage/infoModifyOk";
	}
	
	@GetMapping("/withdrawal")
	public String getWithdrawal(Model model, HttpServletRequest req) {
		HttpSession session = req.getSession();
		if (session.getAttribute("loginMember") == null) {
			return "redirect:/login";

		}

		return "member/sign/withdrawal";
	}
	
	@PostMapping("/withdrawal")
	public String postWithdrawal(Model model, HttpServletRequest req,MemberVo memberVo) {
		HttpSession session = req.getSession();
		
		if (session.getAttribute("loginMember") == null) {
			return "redirect:/login";
		}
		
		memberVo = (MemberVo)session.getAttribute("loginMember");
		service.updateMemberWithdrawal(memberVo);
		
		session.removeAttribute("loginMember");
		
		return "redirect:/";
	}

	@GetMapping("/findPassword")
	public String getFindPassword(Model model, HttpServletRequest req) {
		
		return "member/find/findPassword";
	}
	
	@ResponseBody //json 형식으로 보낼때 필요, map형식으로
	@PostMapping("/findPassword")
	public Map<String,MemberVo> postFindPassword(Model model,HttpServletRequest req,MemberVo memberVo) throws IOException {
		
		memberVo.setId((String)req.getParameter("id"));
		memberVo.setEmail((String)req.getParameter("email"));
		
		memberVo = service.changedMemberPassword(memberVo);
	
		if(memberVo==null) {
			return null;
		}
		Map<String,MemberVo> map = new HashMap<String, MemberVo>();
		map.put("memberVo",memberVo);
		return map;
	}
}
