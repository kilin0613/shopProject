package controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import VO.OrderVo;

@Controller
public class OrderController {
	
	@GetMapping("/orderAndPayment")
	public String getOrderAndPayment(Model model,HttpServletRequest req) {
			HttpSession session = req.getSession();
						
			/*
			 * if (session.getAttribute("loginMember") == null) { return "redirect:/login";
			 * }
			 */
			String name = req.getParameter("product_name");
			String product_id = req.getParameter("product_id");
			String size_option = req.getParameter("size_option");
			String quantity = req.getParameter("quantity");
			String price = req.getParameter("total_price");
			if(product_id!=null && size_option!=null && quantity!=null && price !=null) {
				OrderVo orderVo= new OrderVo();
				orderVo.setName(name);
				orderVo.setProduct_id(product_id);
				orderVo.setQuantity(quantity);
				orderVo.setSize_type(size_option);
				orderVo.setTotal_price(price);
				List<OrderVo> orderList = new ArrayList<OrderVo>();
				orderList.add(orderVo);
				model.addAttribute("orderList",orderList);
			}
			
			
		return "order/orderAndPayment";
	}
	
	@PostMapping("/order")
	public String postOrder(Model model,HttpServletRequest req){
		req.getAttribute("orderList");
		System.out.println(req);
		/* System.out.println(orderList.get(0).getName()); */
		return "";
	}
	
}
